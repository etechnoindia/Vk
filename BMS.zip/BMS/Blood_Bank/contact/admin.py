from django.contrib import admin
from .models import ContactPageBody


admin.site.register(ContactPageBody)
